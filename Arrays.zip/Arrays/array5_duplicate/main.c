#include <stdio.h>

int main()
{
    int array[10] = {1,1,2,2,3,4,4};
    int temporary = 0;
    int totalDups = 0;
    int i, j;

    for(i=0; i<=7; i++){
        temporary = 0;
        for(j=i+1; j<=7; j++){
            if(array[i] == array[j]){
                temporary++;
            }
        }

        if(temporary > 0){
            totalDups++;
        }
    }


    printf("Total duplicate elements are: %d\n", totalDups);
    return 0;
}
