#include <stdio.h>

int main()
{
    int array[] = {2,-1,3,23,8,6};
    int num;

    for(int i=0; i<=6; i++){
        for(int j=i+1; j<=6; j++){
            if(array[i] < array[j]){
                num = array[j];
                array[j] = array[i];
                array[i] = num;
            }
        }
    }

    printf("The second largest element is %d.\n", array[1]);


}
