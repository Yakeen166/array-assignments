#include <stdio.h>

int main()
{
    int row, column;
    printf("Please enter total no of rows:");
    scanf("%d", &row);

    printf("Please enter total no of column:");
    scanf("%d", &column);

    int matrix[row][column];

    printf("Enter rows and columns:");
    for(int i=0; i<row; i++){
        for(int j=0; j<column; j++){
            scanf("%d", &matrix[i][j]);
        }
    }

    int countzero=0;

    for(int i=0; i<row; i++){
        for(int j=0; j<column; j++){
            if(matrix[i][j] == 0){
                countzero++;
            }
        }
    }

    if(countzero > (row*column)/2){
        printf("the given matrix is sparse.\n");
        printf("its sparcity is %d/%d\n", countzero, row*column);
    }else{
        printf("the given matrix is not sparse.\n");
    }
    return 0;
}
