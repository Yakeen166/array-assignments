#include <stdio.h>

int main()
{
    int matrix[3][3] = {{1,2,3},{4,5,6},{7,8,9}};
    int result = 0;

    for(int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            if(i>=j){
                result += matrix[i][j];
                printf("%d\t",matrix[i][j]);
            }else{
                printf("0\t");
            }
        }
        printf("\n");
        printf("\n");
    }

    printf("The sum of upper trianglur elements of the matrix is: %d\n", result);
    return 0;
}
