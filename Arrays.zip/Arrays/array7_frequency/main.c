#include <stdio.h>

int main()
{
    int array[] = {1,1,2,2,3,4,4};
    int temporary;
    int frequency[6] = {};

    for(int i=0; i<=7; i++){
        frequency[i] = -1;
    }

    for(int i=0; i<=7; i++){
        temporary = 1;
        for(int j=i+1; j<=7; j++){
            if(array[i] == array[j]){
                temporary++;
                frequency[j] = 0;
            }
        }

        if(frequency[i] != 0){
            frequency[i] = temporary;
        }
    }

    for(int i=0; i<=7; i++){
        if(frequency[i] != 0){
           printf("%d occurs %d times\n", array[i], frequency[i]);
        }

    }

}
