#include <stdio.h>

int main()
{
    int array[8] = {1,1,1,2,2,3,3,4};
    int count = 0;
    for(int i=0; i<8; i++){
        count = 0;
        for(int j=i+1; j<8; j++){
            if(array[i] == array[j]){
                count++;
            }
        }

        if(count%2 == 0){
            printf("odd\t");
        }
    }

    return 0;
}
