#include <stdio.h>

int main()
{
    int count;
    printf("Enter how many number do you want to print?");
    scanf("%d",&count);

    int num[count];

    for (int i =0; i<count; i++ )
    {
    printf("Enter the number:");
    scanf("%d",&num[i]);
    }

    printf(" the number are in reverse:\n");

    for (int i =count-1; i>=0; i-- )
    {
    printf("%d\t",num[i]);
    }



    return 0;
}
