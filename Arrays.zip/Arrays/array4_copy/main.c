#include <stdio.h>

int main()
{
    int array1[5] = {1,2,3,4,5};
    int array2[] = {};

    for(int i=0; i<=4; i++){
        array2[i] = array1[i];
    }

    for(int i=0; i<=4; i++){
        printf("%d\t", array2[i]);
    }
    printf("\n");
    return 0;
}
