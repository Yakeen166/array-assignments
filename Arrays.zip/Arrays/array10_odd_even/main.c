#include <stdio.h>

int main()
{
    int array[10] = {2,-1,3,23,8,6};
    int arraywithpositive[6] = {};
    int arraywithnegative[6] = {};

    int j = 0;
    for(int i=0; i<=6; i++){
        if(array[i]%2 == 0){
            arraywithpositive[j] = array[i];
            j++;

        }else{
            arraywithnegative[j] = array[i];
            j++;
        }

    }

    printf("Positive elements: \n");
    for(int i =0; i<=6; i++){
        if(arraywithpositive[i] != 0){
            printf("%d\t",arraywithpositive[i]);
        }
    }

    printf("\n");

    printf("Negative elements: \n");
    for(int i =0; i<=6; i++){
        if(arraywithnegative[i] != 0){
            printf("%d\t",arraywithnegative[i]);
        }
    }

    printf("\n");

    return 0;
}
