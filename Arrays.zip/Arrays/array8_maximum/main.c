#include <stdio.h>

int main()
{
    int array[10] = {2,-1,3,23,8,6};

    for(int i=1; i<=6; i++){
        if(array[0] < array[i]){
            array[0] = array[i];
        }
    }

    printf("The largest element is %d.\n", array[0]);


}
