#include <stdio.h>

int main()
{
    int array[6] = {2,-1,3,23,8,6};
    int temp1[6] = {};
    int temp2[6] = {};

    for(int i=0; i<6; i++){
        temp1[i] = array[i];
    }

    for(int i=0; i<6; i++){
        temp2[i] = array[i];
    }

    for(int i=1; i<6; i++){
        if(temp1[0] < temp1[i]){
            temp1[0] = temp1[i];
        }
    }

    for(int i=1; i<6; i++){
        if(temp2[0] > temp2[i]){
            temp2[0] = temp2[i];
        }
    }

    printf("%d is the maxm.\n", temp1[0]);
    printf("%d is the minm.\n", temp2[0]);

    return 0;
}
