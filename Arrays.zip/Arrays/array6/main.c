#include <stdio.h>

int main()
{
int array[]={1,1,2,2,3,4,4};
int i,j;
for(i=0; i<7 ; i++)
{
    for (j=0; j<i ; j++)
    {
        if(array[i]==array[j])

    break;
}
if(i==j)
printf("%d\t",array[i]);


}
printf("\n");




        return 0;
}
