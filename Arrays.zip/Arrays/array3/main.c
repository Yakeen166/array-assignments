#include <stdio.h>

int main()
{
int i;
printf("How many num do you want to print:");
scanf("%d",&i);

int array[i];

for (int j = 0;j <i ;j++)
{
    printf("Enter the number:");
    scanf("%d",&array[j]);

for (int m =i-1;m>=0;m--)
{
printf("%d\t",array[m]);

}
printf("\n");
return 0;


}




